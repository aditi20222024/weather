package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText city;
    Button button;
    TextView Weather App;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set the app title in the action bar
        setTitle("Weather App");


        // Initialize the views
        city = findViewById(R.id.city_name);
        button = findViewById(R.id.button);
        Weather App= findViewById(R.id.app_title); // Optional if you want to manipulate the title TextView

        // Set the onClickListener for the button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getCity = city.getText().toString();

                // Intent to navigate to the next screen
                Intent intent = new Intent(MainActivity.this, Screen2.class);
                intent.putExtra("city", getCity);
                startActivity(intent);
            }
        });
    }
}
